<div class="row">
	<div class="col-lg-12">
		<h4 class="oboro_h4"><i class="fa fa-search" aria-hidden="true"></i> <span>Search An Item</span></h4>
		<div class="table-responsive">
			<table class="table table-hover table-light no-footer table-bordered table-striped table-condensed" id="OboroDT_ItemDB">
				<thead>
					<tr>
						<th>Item ID.</th>
						<th>Name</th>
						<th style="min-width: 400px !important;">Description</th>
						<th>Weight</th>
						<th>Attack</th>
						<th>Defense</th>
						<th>Range</th>
						<th>Slots</th>
						<th>Level</th>
						<th>Dona Val</th>
					</tr>
				</thead>

			</table>
		</div>	
	</div>
</div>