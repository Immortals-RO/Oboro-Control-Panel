
<head>
	<meta charset="utf-8">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="<?php echo $CONFIG->getConfig('Web') ?>img/favicon.ico">
	<title><?php echo $CONFIG->getConfig('title'); ?> - Oboro Contro Panel &copy; Versi&oacute;n <?php echo $CONFIG->getConfig('Oboro_Version') ?></title>

    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
    <link href="<?php echo $CONFIG->getConfig('Web') ?>css/confirm.min.css" rel="stylesheet">
	<link href="<?php echo $CONFIG->getConfig('Web') ?>css/oboro.css" rel="stylesheet">
    
    <script src="<?php echo $CONFIG->getConfig('Web') ?>js/ckeditor.js"></script>
</head>