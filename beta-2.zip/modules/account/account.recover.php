<div class="row">
	<div class="col-lg-8 col-lg-center">
		<h4 class="oboro_h4"><i class="fa fa-user-circle" aria-hidden="true"></i> Recover Account Password</h4>

		<form class="OBOROBACKWORK">
			<table class='table table-hover table-light no-footer table-bordered table-striped table-condensed' id="OboroNDT">
				<tr>
					<td>User ID</td>
					<td>
						<input type="text" class="form-control" name="uid" maxlength="100" size="23" placeholder="Obligatory">
					</td>
				</tr>
				<tr>
					<td>Or E-mail</td>
					<td>
						<input type="text" class="form-control" name="email" maxlength="100" size="23" placeholder="Obligatory">
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input type="hidden" name="OPT" value="RECOVERPASS">
						<input type="submit" class="form-control btn btn-primary" value="Recover My Account Password">
					</td>
				</tr>
			</table>
		</form>	
	</div>
</div>