## Oboro Control Panel By NanoSoft - Isaac (C)

### 1. Enlaces rápidos:

1. [Licenses Oboro CP](https://github.com/OboroControlPanel/Oboro-Control-Panel/wiki/Active-Licenced-Users)
2. [How to install Oboro CP](https://github.com/OboroControlPanel/Oboro-Control-Panel/wiki/How-to-Install-Oboro-Control-Panel)
3. [User-Server Rules](https://github.com/OboroControlPanel/Oboro-Control-Panel/wiki/Getting-Started)
1. [Cómo Instalar un servidor de Ragnarok Correctamente](https://www.facebook.com/notes/nano-soft/manera-correcta-de-instalar-un-servidor/246488552431682)
2. [Host que hasta el día no he tenido problema](http://www.arvixe.com)

